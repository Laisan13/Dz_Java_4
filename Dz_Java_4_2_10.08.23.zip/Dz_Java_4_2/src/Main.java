import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Суммарная стоимость покупок: ");
        double amount = scr.nextDouble();
        System.out.println("Получено денег от покупателя : ");
        double amount_rec = scr.nextDouble();
        double surrender = amount_rec - amount;
        double surrender1 = (surrender-(int)surrender)*100;
        System.out.print("Сдача " + (int)surrender+" рублей");
        System.out.printf(" %.0f", surrender1);
        System.out.print(" копеек ");

    }
}