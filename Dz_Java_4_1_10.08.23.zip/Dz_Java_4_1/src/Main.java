import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.print("Введите длину в погонных метрах: ");
        float line_m = scr.nextFloat();
        System.out.println("Введенная длина в погонных метрах : " + line_m);
        float line_mile = line_m/1600;
        System.out.println("Введенная длина в милях : " + line_mile);
        float line_fut = (line_m*100)/30;
        System.out.println("Введенная длина в футах : " + line_fut);
        float line_arshin = (line_m*100)/72;
        System.out.println("Введенная длина в аршинах : " + line_arshin);

    }
}