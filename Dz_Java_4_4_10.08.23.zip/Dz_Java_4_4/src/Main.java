import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Пользователь вводит целое число. Напишите программу,
        // которая делит это число на 2 и выводит результат.
        // Остаток деления можно отбросить.
        // Операторы деления / и остатка от деления % применять нельзя.
        Scanner scn = new Scanner(System.in);
        System.out.print("Введите число:");
        int num = scn.nextInt();
        System.out.println("Результат деления введенного числа " +
                "на 2 без указания остатка :" + (num>>1));


    }
}